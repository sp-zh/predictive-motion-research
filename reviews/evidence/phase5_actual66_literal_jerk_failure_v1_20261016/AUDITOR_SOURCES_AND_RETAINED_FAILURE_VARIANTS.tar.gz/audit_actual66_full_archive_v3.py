from pathlib import Path
import os,sys,json,ast,struct,hashlib,math,importlib.util,resource
import numpy as np
sys.path.insert(0,'/private/tmp');sys.path.insert(0,'/private/tmp/root65_codec_independent_review_v1_20261016')
from bounded_derived_bytes53_v1 import bounded_write
R=Path('/private/tmp/root66_actual_review_v1_20261016');os.environ['P5_DERIVED53_ROOT']=str(R);resource.setrlimit(resource.RLIMIT_CPU,(180,180))
sp=importlib.util.spec_from_file_location('view66',R/'archive_view66_v2.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);view=m.ArchiveView(R)
# Frozen decoder/math sources only. The following source has no Model/solver API calls.
import reader as nominal_codec
src=Path('/private/tmp/root_independent_controlled_stop52_review_20261012/reference_source/audit_geometry_qp_actual.py');tree=ast.parse(src.read_text());wanted=['state','identity','metadata','values','readmap','nominal','candidate_value','snapshot','validation','initial_validation','commit_record'];exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,ast.ClassDef)and x.name=='R'or isinstance(x,ast.FunctionDef)and x.name in wanted],type_ignores=[]),'<saved-decoders>','exec'),globals());
def take(self,fmt):
 size=struct.calcsize(fmt);assert self.i+size<=len(self.b);out=struct.unpack_from(fmt,self.b,self.i);self.i+=size;return out
R.take=take;R.arr=R.nums;Wire=R;OUT=Path('/private/tmp/root66_actual_review_v1_20261016')
raw=view.raw(view.A+'entry_completion.bin');r=Wire(raw,'ACTIVE_SESSION_FINAL_SCOPE_AND_TIMING');entry={'stage':r.text(),'error':r.text(),'boundary_unchanged':r.u(),'session_termination':r.u(),'session_error':r.text(),'native_termination':r.u(),'native_error':r.text(),'wall_seconds':r.d(),'physical_step_attempts':r.u(),'commits':r.u()};r.end();assert entry['error']=='rounded candidate command derivative bound'and(entry['commits'],entry['physical_step_attempts'],entry['session_termination'],entry['native_termination'])==(51,1102,1,1)
whole=[]
for c in range(52):
 r=Wire(view.raw(view.A+f'cycle-{c}/whole_current_cycle.bin'),'ALL_REJECTED_TRIALS_THROUGH_ONE_ACTUAL_CYCLE_WALL_SCOPE_V1');row=dict(zip(['cycle','trials_entered','physical_complete'],r.take('<3Q')));row.update(wall=r.d(),deadline_miss=r.u(),last_B_error=r.text(),fatal_error=r.text());row.update(zip(['trials_total','forecasts','steps','commits'],r.take('<4Q')));row['scope']=r.text();r.end();assert row['cycle']==c and row['physical_complete']==int(c<51)and row['commits']==min(c+1,51)and row['steps']==2*row['commits']and row['deadline_miss']==int(row['wall']>.004)==1;whole.append(row)
assert(whole[-1]['trials_total'],whole[-1]['forecasts'])==(87,173)
r=Wire(view.raw(view.A+'actual_stop_dwell.bin'),'ACTUAL_PHYSICAL_V_A_ACCEPTED_HISTORY_STOP_DWELL_V2');passed,structural_failed,dwell,required,maximum=r.take('<5Q');limits=r.take('<8d');assert limits==(1e-4,1e-3,1e-6,1e-4,1e-6,1e-4,1e-6,1e-6);count=r.u();assert(count,passed,structural_failed,dwell,required)==(38,0,0,0,50);stops=[];metricfails=[0]*6
for i in range(count):
 half,t=r.take('<Qd');v,a,C,w,alpha=[r.arr(7)for _ in range(5)];s,rate,b=r.take('<3d');guards,below,hold,consecutive=r.take('<4Q');Cd,sd=r.take('<2d');norms=[float(np.max(abs(x)))for x in [v,a,w,alpha]]+[rate,abs(b)];calc=int(all(x<=lim for x,lim in zip(norms,limits[:6])));assert half==1065+i and abs(t-(2.13+.002*i))<1e-12 and guards==1 and below==calc==0 and hold==0 and consecutive==0 and Cd==sd==0
 for j,(x,lim)in enumerate(zip(norms,limits[:6])):metricfails[j]+=int(x>lim)
 stops.append(dict(global_half=half,time_s=t,v=norms[0],a=norms[1],w=norms[2],alpha=norms[3],s=s,r=rate,b=b,below=bool(below),guards=bool(guards),hold_anchor='N/A_NOT_ESTABLISHED',consecutive=consecutive,C_drift=Cd,s_drift=sd))
stop_scope=r.text();r.end();assert metricfails==[36,38,38,38,38,38]
before=view.stored('native66/run-attempt1/BEFORE_INPUT_IDENTITIES.json');after=view.stored('native66/run-attempt1/AFTER_INPUT_IDENTITIES.json');assert before==after and len(json.loads(before))==1745
native_before=snapshot(view.raw(view.A+'cycle-51/trial-0/observation_before.bin'));last_after=snapshot(view.raw(view.accepted[50]+'/observation_after.bin'));assert all(np.array_equal(native_before[k],last_after[k])for k in ['x','alpha','v','a'])and native_before['b']==last_after['b']and native_before['time']==last_after['time']and native_before['steps']==last_after['steps']==1102
# Reuse the completed immutable two-sample arithmetic report from V2.
assert hashlib.sha256((OUT/'FIRST32_LAST49_B400_C2_INDEPENDENT_REVIEW.json').read_bytes()).hexdigest()=='6c8a261e0073fcad04e02025078c17127cad3840b2ccdaa88cae8add6921197c'
b_report=json.loads((OUT/'FIRST32_LAST49_B400_C2_INDEPENDENT_REVIEW.json').read_text());assert [a['cycle']for a in b_report['samples']]==[32,50]
# Parse all20 physical-aware nominal records directly from archive bytes.
fn=next(x for x in ast.parse(Path('/private/tmp/root65_codec_independent_review_v1_20261016/reader.py').read_text()).body if isinstance(x,ast.FunctionDef)and x.name=='parse');fn.name='parse_raw';fn.args.args=[ast.arg(arg='raw'),ast.arg(arg='receipt'),ast.arg(arg='source_complete')];fn.args.defaults=[ast.Constant(value=True)];fn.body=fn.body[1:];ns=dict(vars(nominal_codec));exec(compile(ast.fix_missing_locations(ast.Module(body=[fn],type_ignores=[])),'<nominal-raw-adapter>','exec'),ns);parse_nominal=ns['parse_raw'];constants=json.loads((OUT/'public_constants_snapshot66.json').read_text());start=snapshot(view.raw(view.A+'cycle-0/trial-0/observation_before.bin'));baseline=start['x'][14:21]-start['x'][:7]
def controls(name):
 rr=Wire(view.raw(name),'SOLVER_RESULT_AND_DATA_ONLY_PREVIEW');rr.text();rr.take('<8Q');return rr.vec().reshape(20,8)
def shift(old):
 mesh=nominal_codec.old.MESH;out=np.zeros((20,8));begin=1
 for k in range(20):
  end=begin+mesh[k];oldbegin=0
  for j in range(20):
   oldend=oldbegin+mesh[j];left=max(begin,oldbegin);right=min(end,oldend)
   if right>left:out[k]+=(float(right-left)/mesh[k])*old[j]
   oldbegin=oldend
  begin=end
 return out
nominals=[]
for c in range(32,52):
 name=view.A+f'cycle-{c}/trial-0/stop_objective_mode.bin';o=parse_nominal(view.raw(name),view.read_receipts[name]);b=snapshot(view.raw(view.A+f'cycle-{c}/trial-0/observation_before.bin'));previous=snapshot(view.raw(view.accepted[c-1]+'/observation_after.bin'));assert np.array_equal(previous['x'],b['x'])and np.array_equal(previous['alpha'],b['alpha'])and previous['b']==b['b'];assert np.array_equal(o['baseline_offset'],baseline)
 for key,val in [('q',b['x'][:7]),('v',b['x'][7:14]),('C',b['x'][14:21]),('w',b['x'][21:28]),('alpha',b['alpha'])]:assert np.array_equal(o[key],val)
 assert(o['s'],o['r'],o['b'])==(b['x'][28],b['x'][29],b['b']);replay=nominal_codec.replay(o,constants,warm=shift(controls(view.accepted[c-1]+'/candidate.bin')));nominals.append({'cycle':c,**replay})
assert sum(x['records_replayed']for x in nominals)>19000
out={'schema':'ROOT66_FULL_ARCHIVE_BOUND_TERMINAL_AND_SAVED_ARITHMETIC_REVIEW_V1','reader_V2_failure_preserved':'V2 completed stop/whole and B400/C2 checks, then failed while compiling AST adapter lacking source locations. V3 adds AST locations and reuses frozen B report without rerunning that arithmetic. Legacy B outer label is not published; inner samples are32 and50.', 'reader_V1_failure_preserved':'Old reference R uses nums/u/d rather than take/arr. V1 failed on method lookup before interpreting whole/stop data; V2 adds bounded wire aliases only, no source/solver/Model changes.','archive':view.binding,'entry':entry,'whole_cycles':whole,'stop_records':stops,'stop_per_metric_failures':dict(zip(['v','a','w','alpha','r','b'],metricfails)),'stop_required50_achieved':False,'structural_failed0_is_not_stop_success':True,'hold_false_has_no_anchor_not_drift_fail':True,'all1745_before_after_identical':True,'failed51_before_matches_last50_actual_after':True,'B400_C2_samples':b_report['samples'],'all20_nominal_replays':nominals,'all20_nominal_record_total':sum(x['records_replayed']for x in nominals),'verified_selected_codec_reads':view.read_receipts,'scope':'Independent complete stored-byte recovery and saved original arithmetic only. Samples do not rerun every FCL/Model query; all failures retained. No successful stop, fulltask, real time, hardware or phase acceptance.'};bounded_write(OUT/'ACTUAL66_FULL_INDEPENDENT_REVIEW_V3.json',json.dumps(out,indent=2)+'\n');print(json.dumps({'commits':51,'task_halves':102,'whole':len(whole),'stop_records':len(stops),'dwell':0,'metric_failures':metricfails,'nominal_records':out['all20_nominal_record_total'],'B_samples':[x['cycle']for x in b_report['samples']]}))
