from pathlib import Path
import sys,os,json,math,hashlib,importlib.util,numpy as np
sys.path.insert(0,'/private/tmp');sys.path.insert(0,'/private/tmp/root_independent_controlled_stop52_review_20261012')
from bounded_derived_bytes53_v1 import bounded_write
from compressed_evidence50_v5 import EvidenceReadSet,load_math_definitions
R=Path('/private/tmp/root66_actual_review_v1_20261016');os.environ['P5_DERIVED53_ROOT']=str(R);P=Path('/private/tmp/phase5_saved65_contract_interior_analysis1_20261016/failed51-compact-readback-v1');rs=EvidenceReadSet('tools/cold_storage_verification_v1/strict_codec_reader.py');ref=Path('/private/tmp/root_independent_controlled_stop52_review_20261012/reference_source');n=load_math_definitions(rs,ref/'audit_geometry_qp_actual.py',ref/'audit_actual39.py')
red=n['reduction'](rs.reader.verify_artifact(P/'qp_equality_reduction.bin',True,True)[0]);q=n['inline_full'](rs.reader.verify_artifact(P/'inline_qp.bin',True,True)[0]);before=n['snapshot'](rs.reader.verify_artifact(P/'observation_before.bin',True,True)[0]);sp=importlib.util.spec_from_file_location('g66','tools/phase5_contract_interior66_review_v1/planning_guard_reader.py');guard=importlib.util.module_from_spec(sp);sp.loader.exec_module(guard);v8=guard.parse(P/'planning_guard.bin','tools/cold_storage_verification_v1/strict_codec_reader.py',red['D']);assert v8['role']==guard.NEW and len(v8['interior'])==7
raw=rs.reader.verify_artifact(P/'candidate.bin',True,True)[0];r=guard.Wire(raw);assert r.text()=='P5_ACTIVE_SESSION_LOSSLESS_V1'and r.text()=='SOLVER_RESULT_AND_DATA_ONLY_PREVIEW';reason=r.text();flags=r.take('<8Q');native=r.vec();assert flags[:7]==(0,1,1,0,1,0,1);r.take('<14d');r.take('<4Q');r.text();r.take('<4Q');reported_violation=r.vec();r.u();r.take('<4d');r.take('<2Q');assert r.take('<3Q')==(0,0,0)and r.at==len(raw)
assert np.array_equal(native,red['p']+red['Z']@(red['D']*red['rawx']))and len(native)==160
raw=rs.reader.verify_artifact(P/'current_numeric_hint.bin',True,True)[0];h=guard.Wire(raw);assert h.text()=='P5_ACTIVE_SESSION_LOSSLESS_V1'and h.text()=='BOUNDED_CURRENT_MATRIX_OPTIMIZER_HINT_NOT_CANDIDATE'and h.u()==1;complete=h.u();error=h.text();hx,hy=h.vec(),h.vec();assert complete==1 and error==''and np.array_equal(hx,red['solver_seed']);events=h.u();h.take('<'+str(events*7)+'Q')
# Event bytes contain3Q+4d; consuming exactly56B/event above preserves the wire boundary without interpreting double bits as values.
h.take('<'+str(h.u()*2)+'Q');h.text();assert h.at==len(raw)
hint=red['p']+red['Z']@(red['D']*hx);mesh=[1,1,2,2,3,3,4,4,5,5,6,6,8,10,12,16,20,24,28,40]
def literal(U):
 w=list(map(float,before['x'][21:28]));C=list(map(float,before['x'][14:21]));previous=list(map(float,before['alpha']));failed=[];tick=0
 for k,m in enumerate(mesh):
  for step in range(m):
   tick+=1
   for j in range(7):
    a=float(U[8*k+j]);nw=w[j]+.004*a;nc=C[j]+.004*nw;ia=(nw-w[j])/.004;jj=(ia-previous[j])/.004
    for field,value,bound in [('alpha',a,1.),('implied_alpha',ia,1.),('jerk',jj,20.),('command_speed',nw,.0625)]:
     if abs(value)>bound:failed.append({'tick':tick,'cell0':k,'step0':step,'joint0':j,'field':field,'value':value,'bound':bound,'positive_excess':abs(value)-bound,'ULPs':(abs(value)-bound)/math.ulp(bound),'before_w':w[j],'previous_accepted_alpha':previous[j],'raw_alpha':a,'rounded_implied_alpha':ia,'next_w':nw})
    w[j],C[j],previous[j]=nw,nc,ia
 assert tick==200
 return failed
results={}
for name,U in [('genuine_nominal',q['seed']),('hint',hint),('native',native)]:
 ax=q['A']@U;v=np.maximum(np.maximum(q['l']-ax,ax-q['u']),0);worst=int(np.argmax(v));history=n['rounded_history'](before['x'],before['alpha'],before['b'],U,mesh,q['labels'],q['l'],q['u']);results[name]={'literal_derivative_failures':literal(U),'full_original_SI_max_violation':float(np.max(v)),'original_SI_worst_row':worst,'original_SI_worst_label':q['labels'][worst],'full200_history_failures':history['failures']}
assert not results['genuine_nominal']['literal_derivative_failures']and not results['hint']['literal_derivative_failures'];f=results['native']['literal_derivative_failures'];assert len(f)==1 and(f[0]['tick'],f[0]['joint0'],f[0]['field'])==(1,1,'jerk')and f[0]['value']==-20.000000000010623
strict=[]
for j,a in enumerate(v8['first']):
 gap=math.nextafter(abs(a['w']+.004*float(native[j])),math.inf)-a['strict_bound'];assert gap<=0;strict.append(gap)
assert len(q['l'])==14756 and red['As'].shape==(7338,144)and max(reported_violation)<=1e-7
out={'schema':'ROOT66_FAILED51_EXACT_ORIGINAL_LITERAL_DERIVATIVE_CAUSE_V1','current_scaled_rows':len(red['ls']),'original_SI_rows':len(q['l']),'candidate_flags':flags,'candidate_preview_tail_forward_absent':True,'recorded_native_u_exact_p_Z_D_x':True,'all_three_saved_controls':results,'hint_events':events,'native_joint2_alpha_minus_hint':float(native[1]-hint[1]),'strict_first7_gaps':strict,'V8_all7x9_policy_records_exact':True,'native_or_Model_calls_in_audit':0,'scope':'Exact retained binary64 arithmetic only. Native moves across original20jerk active bound; original SI1e-7 can pass while unchanged strict literal gate correctly refuses. Does not establish QP infeasibility, actual physical stopping or acceptance.'};bounded_write(R/'FAILED51_EXACT_DERIVATIVE_CAUSE_INDEPENDENT_REVIEW_V1.json',json.dumps(out,indent=2)+'\n');print(json.dumps(out))
