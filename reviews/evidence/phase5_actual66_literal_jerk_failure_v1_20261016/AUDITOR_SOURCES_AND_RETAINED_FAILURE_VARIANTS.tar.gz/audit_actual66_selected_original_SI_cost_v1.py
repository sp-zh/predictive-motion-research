from pathlib import Path
import os,sys,json,importlib.util,hashlib
sys.path.insert(0,'/private/tmp');from bounded_derived_bytes53_v1 import bounded_write
OUT=Path('/private/tmp/root66_actual_review_v1_20261016');os.environ['P5_DERIVED53_ROOT']=str(OUT);sp=importlib.util.spec_from_file_location('view66',OUT/'archive_view66_v3.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);view=m.ArchiveView(OUT);reports=[]
original=Path('/private/tmp/root65_actual_review_v1_20261016/FIRST32_original_si_review_v1.py').read_text()
for cycle,base in view.samples:
 source=original.replace('from bounded_derived_bytes53_v1 import bounded_write','bounded_write=capture').replace('strict = nominal.strict','strict = view').replace("Path('/private/tmp/root65_actual_review_v1_20261016')","Path('/private/tmp/root66_actual_review_v1_20261016')").replace("'selected/native65/run-attempt1/artifacts'","'selected/native66/run-attempt1/artifacts'").replace("P = A / 'cycle-32/trial-0'","P = view.virtual / "+repr(base)).replace("'ROOT65_ACTUAL_FIRST32_FULL_ORIGINAL_SI_AND_COST_FACTOR_REVIEW_V1'","'ROOT66_SELECTED_FULL_ORIGINAL_SI_AND_COST_FACTOR_REVIEW_V1'").replace('current=32, trial=0','current='+str(cycle)+', trial='+base.split('/trial-')[-1]).replace('Saved actual65 current32','Saved actual66 selected current'+str(cycle))
 def capture(path,text):reports.append(json.loads(text))
 exec(compile(source,'<full-si-cost-auditor66>','exec'),{'view':view,'capture':capture})
assert [x['current']for x in reports]==[32,50]
os.environ['P5_DERIVED53_ROOT']=str(OUT);out={'schema':'ROOT66_SELECTED_ORIGINAL_SI_COST_FACTOR_REVIEW_V1','samples':reports,'archive_binding':view.binding,'source_auditor_SHA256':hashlib.sha256(original.encode()).hexdigest(),'new_Model_or_solver_calls':0,'scope':'First32 and last50 original14756 SI and909row cost factor consistency; all failures retained. Does not establish stop/fulltask/realtime/phase acceptance.'};bounded_write(OUT/'FIRST32_LAST50_ORIGINAL_SI_COST_REVIEW_V1.json',json.dumps(out,indent=2)+'\n');print(json.dumps({'samples':[{'cycle':r['current'],'SI_violation':r['full_original_SI_violation_numpy']}for r in reports]}))
