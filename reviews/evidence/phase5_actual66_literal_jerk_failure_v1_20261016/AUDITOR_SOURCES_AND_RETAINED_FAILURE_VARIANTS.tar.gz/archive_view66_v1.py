"""Bounded in-memory view of selected members from verified immutable complete66.
No extracted native files, Model or solver invocations. Original stored/codec
identities are checked on every raw read; all unselected bytes remain archived.
"""
from pathlib import Path
import json,hashlib,gzip,tarfile,zlib,re
class ArchiveView:
 def __init__(self,root):
  self.root=Path(root);self.backup=Path('/Users/uot/Documents/ChatGPT/ros/transfer/cold-backups/native66-complete-direct-mac-20261016-v1');self.virtual=self.root/'selected';self.manifest=json.loads((self.backup/'SOURCE_MANIFEST.json').read_text());self.prepared=json.loads((self.backup/'PRODUCER_PREPARED.json').read_text());self.rows={e['path']:e for e in self.manifest['files']};self.codecs={self.prepared['prefix']+str(Path(e['file']).relative_to(self.prepared['native_source'])):e for e in json.loads((self.backup/'FULL_NATIVE_CODEC_READBACK.json').read_text())['files']};self.cache={};self.read_receipts={};self.A='native66/run-attempt1/artifacts/';wanted=set()
  self.accepted={}
  for c in range(51):
   hits=[n for n in self.rows if re.fullmatch(re.escape(self.A)+f'cycle-{c}/trial-[012]/observation_after.bin',n)];assert len(hits)==1;self.accepted[c]=hits[0].rsplit('/',1)[0]
   wanted|={hits[0],self.accepted[c]+'/candidate.bin'}
  for c in range(32,52):wanted|={self.A+f'cycle-{c}/trial-0/'+name for name in ['stop_objective_mode.bin','observation_before.bin']}
  wanted|={n for n in self.rows if re.fullmatch(re.escape(self.A)+r'cycle-[0-9]+/whole_current_cycle.bin',n)}
  wanted|={self.A+n for n in ['entry_completion.bin','actual_stop_dwell.bin']}
  wanted|={'native66/'+n for n in ['DERIVED_TERMINAL66_SUMMARY.json','ENTRY_CONSUMED66.json','run-attempt1/BEFORE_INPUT_IDENTITIES.json','run-attempt1/AFTER_INPUT_IDENTITIES.json']}
  self.samples=[]
  for cycle in [32,50]:
   base=self.accepted[cycle];self.samples.append((cycle,base))
   wanted|={base+'/'+n for n in ['observation_before.bin','observation_after.bin','original_nominal.bin','candidate_value.bin','candidate_validation.bin','validation_initial.bin','actual_commit.bin']}
  assert wanted<=set(self.rows)and len(wanted)<=256 and sum(self.rows[n]['bytes']for n in wanted)<=64<<20
  path=self.backup/'complete.tar.gz';before=path.stat();expected='f1b179d4271dc99a8a3f1dd5a1c056afd2f98db785db642bde1de04640056498';h=hashlib.sha256();count=0
  class Hashed:
   def __init__(self,f):self.f=f
   def read(self,n=-1):
    nonlocal count
    b=self.f.read(n);h.update(b);count+=len(b);return b
  with path.open('rb')as f:
   with gzip.GzipFile(fileobj=Hashed(f),mode='rb')as gz:
    with tarfile.open(fileobj=gz,mode='r|')as tf:
     for item in tf:
      if item.name in wanted:
       row=self.rows[item.name];assert item.isfile()and item.size==row['bytes'];data=tf.extractfile(item).read(item.size+1);assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256'];self.cache[item.name]=data
    while gz.read(65536):pass
  after=path.stat();assert(before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns)and count==before.st_size==1822543482 and h.hexdigest()==expected and set(self.cache)==wanted
  self.binding={'archive_sha256':expected,'archive_bytes':count,'outer_full_reopened_SHA_CRC_single_gzip_EOF_again_verified':True,'cached_members':len(self.cache),'cached_stored_bytes':sum(map(len,self.cache.values())),'maximum_in_memory_stored_bytes':64<<20,'new_extracted_native_files':0,'samples':self.samples}
 def stored(self,name):
  assert name in self.cache;return self.cache[name]
 def raw(self,name):
  b=self.stored(name);e=self.codecs[name];assert e['source_complete']and e['closed_raw_prefix_valid']and len(b)==e['stored_bytes']and hashlib.sha256(b).hexdigest()==e['stored_sha256']and e['raw_bytes']<=128<<20
  if e['codec']=='GZIP_DEFLATE_V1':
   z=zlib.decompressobj(31);raw=z.decompress(b,e['raw_bytes']+1);assert z.eof and not z.unused_data and not z.unconsumed_tail
  else:assert e['codec']=='RAW_V1';raw=b
  assert len(raw)==e['raw_bytes']and hashlib.sha256(raw).hexdigest()==e['raw_sha256'];self.read_receipts[name]={'stored_bytes':len(b),'stored_sha256':e['stored_sha256'],'raw_bytes':len(raw),'raw_sha256':e['raw_sha256'],'source_complete':True};return raw
 def read_artifact_bytes(self,path):return self.raw(str(Path(path).relative_to(self.virtual)))
